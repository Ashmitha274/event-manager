// Countdown Timer for Main Event
function startCountdown() {
    const eventDate = new Date("April 25, 2025 00:00:00").getTime();

    const countdown = setInterval(function () {
        const now = new Date().getTime();
        const timeLeft = eventDate - now;

        if (timeLeft < 0) {
            clearInterval(countdown);
            document.getElementById("countdown").innerHTML = "🎉 Event Started!";
            return;
        }

        const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

        document.getElementById("countdown").innerHTML =
            `${days}d ${hours}h ${minutes}m ${seconds}s`;
    }, 1000);
}

// Call the countdown on page load
startCountdown();

// Show the form for the selected event
function openForm(event) {
    closeForm(); // hide any open forms

    if (event === "sandalwood") {
        document.getElementById("sandalwood-registration").style.display = "block";
    } else if (event === "bollywood") {
        document.getElementById("bollywood-registration").style.display = "block";
    } else if (event === "dj") {
        document.getElementById("dj-registration").style.display = "block";
    }
}

// Hide all registration forms
function closeForm() {
    const forms = ["sandalwood-registration", "bollywood-registration", "dj-registration"];
    forms.forEach(formId => {
        const form = document.getElementById(formId);
        if (form) form.style.display = "none";
    });
}
